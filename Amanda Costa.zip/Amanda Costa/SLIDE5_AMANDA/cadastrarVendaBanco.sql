create database exercicio3;
use exercicio3;

create table Venda(
	id int auto_increment primary key,
    codigo int,
    nomeVendedor varchar(255),
    nomeProduto varchar(255)
);