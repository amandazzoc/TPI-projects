create database exercicio2;

use exercicio2;

create table Produto(
	id int auto_increment primary key,
    codigo int,
    nomeProduto varchar(255),
    descricao varchar(255)
);